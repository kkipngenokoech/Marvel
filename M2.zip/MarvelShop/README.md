# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

## instructions to use

1. clone the repository
2. run rails db:migrate
3. run rails db:seed
4. run rails s

check your browser for the implementations.
