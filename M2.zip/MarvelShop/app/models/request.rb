class Request < ApplicationRecord
end
